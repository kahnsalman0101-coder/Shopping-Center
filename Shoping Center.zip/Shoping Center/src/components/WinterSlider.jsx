import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination, Navigation } from "swiper/modules";
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";
import "../style/WinterSlider.css";

const winterImages = [
  "/WinterSlider/500x500-aura_cd6eb830-2078-42c0-9b7b-599a2db95213_600x600.webp",
  "/WinterSlider/500x500-lux-pret_ad15a7e6-261c-4a2f-b225-7bbe71205ea7_600x600.webp",
  "/WinterSlider/500x500-pret_613601c4-d27d-4eb0-987f-b277f93deb5d_600x600.jpg",
  "/WinterSlider/500x500-unstitched-printed_7cff4e0e-0983-4f58-af08-c4193e0ed8be_600x600.webp",
  "/WinterSlider/500x500-unstitched_c623f23d-1579-4887-a76f-5987d86719dc_600x600.webp",
  "/WinterSlider/500x500-aura_cd6eb830-2078-42c0-9b7b-599a2db95213_600x600.webp",
  "/WinterSlider/500x500-lux-pret_ad15a7e6-261c-4a2f-b225-7bbe71205ea7_600x600.webp",
  "/WinterSlider/500x500-pret_613601c4-d27d-4eb0-987f-b277f93deb5d_600x600.jpg",
  "/WinterSlider/500x500-unstitched-printed_7cff4e0e-0983-4f58-af08-c4193e0ed8be_600x600.webp",
  "/WinterSlider/500x500-unstitched_c623f23d-1579-4887-a76f-5987d86719dc_600x600.webp",
];

export default function WinterSlider() {
  return (
    <div className="winter-slider-section">
      {/* Left side title */}
      <div className="winter-title-side">
        <h1>WINTER  2025</h1>
      </div>

      {/* Right side Swiper */}
      <div className="winter-slider-container">
        <Swiper
          spaceBetween={30}
          centeredSlides={true}
          autoplay={{
            delay: 3000,
            disableOnInteraction: false,
          }}
          pagination={{ clickable: true }}
          navigation
          modules={[Autoplay, Pagination, Navigation]}
          className="winter-slider"
        >
          {/* Slide 1 */}
          <SwiperSlide>
            <div className="winter-images-group">
              {winterImages.slice(0, 5).map((src, i) => (
                <div key={i} className="winter-circle">
                  <img src={src} alt={`Winter ${i + 1}`} />
                </div>
              ))}
            </div>
          </SwiperSlide>

          {/* Slide 2 */}
          <SwiperSlide>
            <div className="winter-images-group">
              {winterImages.slice(5, 10).map((src, i) => (
                <div key={i} className="winter-circle">
                  <img src={src} alt={`Winter ${i + 6}`} />
                </div>
              ))}
            </div>
          </SwiperSlide>
        </Swiper>
      </div>
    </div>
  );
}
