import React, { useState, useEffect, useRef } from "react";
import { 
  FaBars, 
  FaShoppingCart, 
  FaSearch, 
  FaTimes, 
  FaTag, 
  FaTshirt, 
  FaShoePrints,
  FaUserCircle,
  FaTimesCircle
} from "react-icons/fa";
import { useNavigate, Link } from "react-router-dom";
import { useCart } from "../context/CartContext";
import AuthModal from "./AuthModal";
import UserDropdown from "./UserDropdown";
import "../style/Navbar.css";

function Navbar() {
  const navigate = useNavigate();
  const { cartItems, cartStats } = useCart();
  const [searchQuery, setSearchQuery] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showMobileSearch, setShowMobileSearch] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showCategoriesSidebar, setShowCategoriesSidebar] = useState(false);
  
  // Check if user is logged in
  const [userLoggedIn, setUserLoggedIn] = useState(() => {
    const savedUser = localStorage.getItem('fashionhub_user');
    return savedUser ? true : false;
  });
  
  const [userData, setUserData] = useState(() => {
    const savedUser = localStorage.getItem('fashionhub_user');
    return savedUser ? JSON.parse(savedUser) : null;
  });

  const searchRef = useRef(null);
  const sidebarRef = useRef(null);
  const categoriesSidebarRef = useRef(null);

  // Categories for main sidebar
  const categories = [
    { name: "New Arrivals", icon: "🆕", count: 24, path: "/products?category=new" },
    { name: "Winter Collection", icon: "❄️", count: 42, path: "/products?category=winter" },
    { name: "Summer Lawn", icon: "☀️", count: 36, path: "/products?category=summer" },
    { name: "Formal Wear", icon: "👔", count: 18, path: "/products?category=formal" },
    { name: "Casual Collection", icon: "👚", count: 29, path: "/products?category=casual" },
    { name: "Accessories", icon: "💍", count: 15, path: "/products?category=accessories" },
    { name: "Footwear", icon: "👟", count: 22, path: "/products?category=footwear" },
    { name: "Sale", icon: "💰", count: 58, path: "/products?category=sale" },
  ];

  // Categories for top-left sidebar
  const topCategories = [
    { name: "New Arrivals", icon: "🌟", path: "/products?category=new" },
    { name: "Festive Collection", icon: "🎉", path: "/products?category=festive" },
    { name: "Summer Drop 2025", icon: "☀️", path: "/products?category=summer" },
    { name: "Luxury Lawn", icon: "👗", path: "/products?category=luxury" },
    { name: "Designer Wear", icon: "🎨", path: "/products?category=designer" },
    { name: "Bridal Collection", icon: "👰", path: "/products?category=bridal" },
    { name: "Kids Fashion", icon: "👶", path: "/products?category=kids" },
    { name: "Men's Collection", icon: "👨", path: "/products?category=men" },
    { name: "Women's Collection", icon: "👩", path: "/products?category=women" },
    { name: "Accessories", icon: "💍", path: "/products?category=accessories" },
    { name: "Footwear", icon: "👠", path: "/products?category=footwear" },
    { name: "Winter Special", icon: "❄️", path: "/products?category=winter" },
  ];

  // Handle user login success
  const handleLoginSuccess = (user) => {
    setUserLoggedIn(true);
    setUserData(user);
    setShowAuthModal(false);
  };

  // Handle user logout
  const handleLogout = () => {
    localStorage.removeItem('fashionhub_user');
    setUserLoggedIn(false);
    setUserData(null);
    // Show toast notification
    if (window.toast) {
      window.toast.success('Logged out successfully!');
    }
  };

  // Mock API call for suggestions
  const fetchSuggestions = async (query) => {
    if (query.length < 2) {
      setSuggestions([]);
      return;
    }

    setIsLoading(true);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 300));
    
    const mockSuggestions = [
      { text: "Men's T-Shirts", icon: <FaTshirt />, category: "Clothing" },
      { text: "Running Shoes", icon: <FaShoePrints />, category: "Footwear" },
      { text: "Summer Sale", icon: <FaTag />, category: "Deals" },
      { text: "Casual Jeans", icon: <FaTshirt />, category: "Clothing" },
      { text: "Watches", icon: <FaTag />, category: "Accessories" },
      { text: "Winter Jackets", icon: <FaTshirt />, category: "Clothing" },
      { text: "Formal Shirts", icon: <FaTshirt />, category: "Clothing" },
      { text: "Sunglasses", icon: <FaTag />, category: "Accessories" },
    ].filter(item => 
      item.text.toLowerCase().includes(query.toLowerCase()) ||
      item.category.toLowerCase().includes(query.toLowerCase())
    );
    
    setSuggestions(mockSuggestions);
    setIsLoading(false);
  };

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Close suggestions and sidebars when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      // Close search suggestions
      if (searchRef.current && !searchRef.current.contains(event.target)) {
        setShowSuggestions(false);
      }
      
      // Close main sidebar
      if (sidebarRef.current && 
          !sidebarRef.current.contains(event.target) &&
          !event.target.closest('.menu-btn')) {
        setSidebarOpen(false);
      }
      
      // Close categories sidebar
      if (categoriesSidebarRef.current && 
          !categoriesSidebarRef.current.contains(event.target) &&
          !event.target.closest('.categories-btn')) {
        setShowCategoriesSidebar(false);
      }
      
      // Close mobile search
      if (!event.target.closest('.mobile-search-toggle') && 
          !event.target.closest('.mobile-search-container')) {
        setShowMobileSearch(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSearchChange = (e) => {
    const value = e.target.value;
    setSearchQuery(value);
    fetchSuggestions(value);
    setShowSuggestions(true);
  };

  const handleSearch = (e) => {
    e.preventDefault();
    const query = searchQuery.trim();
    if (query) {
      navigate("/products", { state: { searchQuery: query } });
      setSearchQuery("");
      setShowSuggestions(false);
      setShowMobileSearch(false);
    }
  };

  const handleSuggestionClick = (suggestion) => {
    setSearchQuery(suggestion.text);
    navigate("/products", { state: { searchQuery: suggestion.text } });
    setShowSuggestions(false);
    setShowMobileSearch(false);
  };

  const handleClearSearch = () => {
    setSearchQuery("");
    setSuggestions([]);
    setShowSuggestions(false);
  };

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const toggleCategoriesSidebar = () => {
    setShowCategoriesSidebar(!showCategoriesSidebar);
  };

  const handleCategoryClick = (category) => {
    navigate(category.path);
    setSidebarOpen(false);
    setShowCategoriesSidebar(false);
  };

  return (
    <>
      {/* Main Navbar */}
      <nav className={`custom-navbar ${scrolled ? 'scrolled' : ''}`}>
        {/* Categories Button (Top-Left) */}
        <button 
          className="categories-btn"
          onClick={toggleCategoriesSidebar}
          aria-label="Browse categories"
        >
          <FaBars className="categories-icon" />
          <span className="categories-text">Categories</span>
        </button>

        {/* Mobile Menu Button */}
        <button 
          className="menu-btn" 
          onClick={toggleSidebar}
          aria-label="Toggle menu"
        >
          <FaBars className="menu-icon" />
        </button>

        {/* Logo/Brand */}
        <div className="logo" onClick={() => navigate("/")} role="button" tabIndex={0}>
          <span className="logo-text">FashionHub</span>
          <span className="logo-badge">NEW</span>
        </div>

        {/* Desktop Search */}
        <div className="search-container" ref={searchRef}>
          <form 
            className={`search-form ${isLoading ? 'loading' : ''}`}
            onSubmit={handleSearch}
          >
            <input
              type="text"
              className="search-box"
              placeholder="Search for products, brands, and more..."
              value={searchQuery}
              onChange={handleSearchChange}
              onFocus={() => setShowSuggestions(true)}
              aria-label="Search products"
            />
            {searchQuery && (
              <button 
                type="button"
                className="clear-search"
                onClick={handleClearSearch}
                aria-label="Clear search"
              >
                <FaTimes />
              </button>
            )}
            <button 
              className="search-btn" 
              type="submit"
              disabled={isLoading}
              aria-label={isLoading ? "Searching..." : "Search"}
            >
              <FaSearch />
            </button>
            {isLoading && <div className="search-progress"></div>}
          </form>

          {/* Search Suggestions */}
          {showSuggestions && suggestions.length > 0 && (
            <div className="search-suggestions">
              <div className="suggestions-header">
                <span>Popular Suggestions</span>
              </div>
              {suggestions.map((suggestion, index) => (
                <div
                  key={index}
                  className="suggestion-item"
                  onClick={() => handleSuggestionClick(suggestion)}
                  role="button"
                  tabIndex={0}
                >
                  <span className="suggestion-icon">{suggestion.icon}</span>
                  <span className="suggestion-text">{suggestion.text}</span>
                  <span className="suggestion-category">{suggestion.category}</span>
                </div>
              ))}
            </div>
          )}
          
        </div>

        {/* Actions */}
        <div className="nav-actions">
      

          {/* User Account */}
          {userLoggedIn ? (
            <UserDropdown 
              user={userData} 
              onLogout={handleLogout}
            />
          ) : (
            <button 
              className="account-btn"
              onClick={() => setShowAuthModal(true)}
              aria-label="Login"
            >
              <FaUserCircle />
              <span className="action-text">Login</span>
            </button>
          )}

          {/* Mobile Search Toggle */}
          <button 
            className="mobile-search-toggle"
            onClick={() => setShowMobileSearch(true)}
            aria-label="Open search"
          >
            <FaSearch />
          </button>

          {/* Cart */}
          <div 
            className={`cart-container ${cartItems.length === 0 ? 'empty' : ''}`}
            onClick={() => navigate("/cart")}
            role="button"
            tabIndex={0}
            aria-label={`Shopping cart, ${cartStats?.totalItems || cartItems.length} items`}
          >
            <FaShoppingCart className="cart-icon" />
            <span className="cart-text">Cart</span>
            {cartStats?.totalItems > 0 && (
              <span className="cart-count">{cartStats.totalItems > 99 ? '99+' : cartStats.totalItems}</span>
            )}
          </div>

        </div>

      </nav>

      {/* Categories Sidebar (Top-Left) */}
      <div className={`categories-overlay ${showCategoriesSidebar ? 'active' : ''}`} onClick={toggleCategoriesSidebar} />
      <div className={`categories-sidebar ${showCategoriesSidebar ? 'open' : ''}`} ref={categoriesSidebarRef}>
        <div className="categories-header">
          <h2>🛍️ Shop by Category</h2>
          <button className="close-categories" onClick={toggleCategoriesSidebar}>
            <FaTimesCircle />
          </button>
        </div>
        
        <div className="categories-list">
          {topCategories.map((category, index) => (
            <button 
              key={index}
              className="category-item"
              onClick={() => handleCategoryClick(category)}
            >
              <span className="category-item-icon">{category.icon}</span>
              <span className="category-item-name">{category.name}</span>
              <span className="category-item-arrow">→</span>
            </button>
          ))}
        </div>

        <div className="categories-footer">
          <div className="trending-tags">
            <span className="trending-label">🔥 Trending:</span>
            <button className="trending-tag" onClick={() => navigate("/products?category=sale")}>
              #Sale
            </button>
            <button className="trending-tag" onClick={() => navigate("/products?category=new")}>
              #NewArrivals
            </button>
            <button className="trending-tag" onClick={() => navigate("/products?category=popular")}>
              #Popular
            </button>
          </div>
        </div>
      </div>

      {/* Auth Modal */}
      {showAuthModal && (
        <AuthModal 
          onClose={() => setShowAuthModal(false)}
          onLoginSuccess={handleLoginSuccess}
        />
      )}


      {/* Mobile Search Overlay */}
      {showMobileSearch && (
        <div className="mobile-search-overlay active">
          <div className="mobile-search-container">
            <form 
              className="search-form"
              onSubmit={handleSearch}
            >
              <input
                type="text"
                className="search-box"
                placeholder="Search products..."
                value={searchQuery}
                onChange={handleSearchChange}
                autoFocus
              />
              <button 
                type="button"
                className="clear-search"
                onClick={handleClearSearch}
              >
                <FaTimes />
              </button>
              <button className="search-btn" type="submit">
                <FaSearch />
              </button>
            </form>
            
            {showSuggestions && suggestions.length > 0 && (
              <div className="mobile-suggestions">
                {suggestions.map((suggestion, index) => (
                  <div
                    key={index}
                    className="suggestion-item"
                    onClick={() => handleSuggestionClick(suggestion)}
                  >
                    <span className="suggestion-icon">{suggestion.icon}</span>
                    {suggestion.text}
                  </div>
                ))}
              </div>
            )}
            
            <button 
              className="close-overlay"
              onClick={() => setShowMobileSearch(false)}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
}

export default Navbar;