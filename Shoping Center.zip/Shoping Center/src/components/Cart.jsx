import React, { useState } from "react";
import { useCart } from "../context/CartContext"; // adjust path if Cart.jsx is in components
import "../style/Cart.css";

function Cart() {
  const { 
    cartItems, 
    cartStats,
    removeFromCart, 
    updateQuantity,
    clearCart,
    moveToWishlist,
    saveForLater,
    applyCoupon 
  } = useCart();
  
  const [showModal, setShowModal] = useState(false);
  const [couponCode, setCouponCode] = useState("");
  const [couponApplied, setCouponApplied] = useState(null);
  const [checkoutData, setCheckoutData] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    zipCode: ""
  });

  // Empty cart case
  if (cartItems.length === 0)
    return (
      <div className="empty-cart-container">
        <h2 className="empty-cart">🛒 Your cart is feeling lonely</h2>
        <p className="empty-cart-text">
          Add some stylish items and make it happy! Explore our collection and 
          find something that speaks to your style 💫
        </p>
        <a href="/products" className="shop-now-btn">
          ✨ Explore Collection
        </a>
        
        {/* Load saved cart option */}
        <button className="load-saved-btn" onClick={saveForLater}>
          📥 Check Saved Cart
        </button>
      </div>
    );

  // Handle coupon application
  const handleApplyCoupon = () => {
    if (!couponCode.trim()) {
      alert("Please enter a coupon code");
      return;
    }
    
    const result = applyCoupon(couponCode);
    if (result) {
      setCouponApplied(result);
    }
  };

  // Calculate final total with coupon
  const calculateFinalTotal = () => {
    // FIXED: cartStats.grandTotal is a property, not a function
    let total = cartStats.grandTotal || 0;
    
    if (couponApplied) {
      if (couponApplied.type === "freeshipping") {
        total -= couponApplied.value;
      } else if (couponApplied.type === "percentage") {
        total -= couponApplied.amount;
      }
    }
    
    return Math.max(0, total).toFixed(0);
  };

  // Calculate item price (handles string or number)
  const getItemPrice = (item) => {
    if (typeof item.price === 'string') {
      return parseFloat(item.price.replace(/[^0-9.]/g, "")) || 0;
    }
    return Number(item.price) || 0;
  };

  // Handle form submission
  const handleCheckoutSubmit = (e) => {
    e.preventDefault();
    
    const orderDetails = {
      orderId: `ORD-${Date.now()}`,
      customer: checkoutData,
      items: cartItems,
      subtotal: cartStats.totalPrice,
      shipping: cartStats.shippingCost,
      tax: cartStats.tax,
      discount: couponApplied ? couponApplied.amount || couponApplied.value : 0,
      total: calculateFinalTotal(),
      date: new Date().toISOString()
    };
    
    // Save order to localStorage
    const existingOrders = JSON.parse(localStorage.getItem("fashionhub_orders") || "[]");
    localStorage.setItem("fashionhub_orders", JSON.stringify([orderDetails, ...existingOrders]));
    
    alert(
      `🎉 Order Confirmed!\n\nOrder ID: ${orderDetails.orderId}\nThank you, ${checkoutData.name}!\nTotal: Rs ${orderDetails.total}\n\nWe've sent order details to ${checkoutData.email}\nOur team will contact you soon for delivery.`
    );
    
    setShowModal(false);
    clearCart();
    setCheckoutData({ name: "", email: "", phone: "", address: "", city: "", zipCode: "" });
    setCouponApplied(null);
    setCouponCode("");
  };

  return (
    <div className="cart-page">
      <h2 className="cart-title">🛍️ Your Shopping Cart ({cartStats.totalItems} items)</h2>

      <div className="cart-list">
        {cartItems.map((item) => {
          const itemPrice = getItemPrice(item);
          return (
            <div key={item.id} className="cart-item">
              <img src={item.img} alt={item.name} className="cart-img" />
              <div className="cart-details">
                <h3 className="cart-item-name">{item.name}</h3>
                {/* FIXED: Changed cartStats.totalPrice to item.price */}
                <p className="cart-item-price">
                  Rs {itemPrice} × {item.quantity}
                </p>
                
                <div className="quantity-controls">
                  <button 
                    className="quantity-btn"
                    onClick={() => updateQuantity(item.id, Math.max(0, item.quantity - 1))}
                  >
                    −
                  </button>
                  <span className="quantity-display">{item.quantity}</span>
                  <button 
                    className="quantity-btn"
                    onClick={() => updateQuantity(item.id, item.quantity + 1)}
                  >
                    +
                  </button>
                </div>
                
                <p className="cart-item-subtotal">
                  Subtotal: Rs {(item.quantity * itemPrice).toFixed(0)}
                </p>
                
                <div className="item-actions">
                  <button 
                    className="wishlist-move-btn"
                    onClick={() => moveToWishlist(item.id)}
                  >
                    💖 Save for Later
                  </button>
                  <button 
                    className="remove-btn" 
                    onClick={() => removeFromCart(item.id)}
                  >
                    🗑️ Remove
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="cart-summary">
        <h3>
          Order Summary
          <span className="cart-total">Rs {calculateFinalTotal()}</span>
        </h3>
        
        <div className="order-summary">
          <div className="order-item">
            <span>Subtotal ({cartStats.totalItems} items)</span>
            <span>Rs {(cartStats.totalPrice || 0).toFixed(0)}</span>
          </div>
          <div className="order-item">
            <span>Shipping</span>
            <span className={cartStats.isFreeShipping ? "free-shipping" : ""}>
              {cartStats.isFreeShipping ? 'FREE 🎉' : `Rs ${cartStats.shippingCost || 0}`}
            </span>
          </div>
          <div className="order-item">
            <span>Tax (16%)</span>
            <span>Rs {(cartStats.tax || 0).toFixed(0)}</span>
          </div>
          
          {/* Coupon Section */}
          <div className="coupon-section">
            <div className="coupon-input-group">
              <input
                type="text"
                placeholder="Enter coupon code"
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value)}
                className="coupon-input"
              />
              <button 
                className="coupon-btn"
                onClick={handleApplyCoupon}
              >
                Apply
              </button>
            </div>
            {couponApplied && (
              <div className="coupon-applied">
                <span>Coupon Applied!</span>
                <span className="discount-amount">
                  -Rs {couponApplied.type === "percentage" 
                    ? (couponApplied.amount || 0).toFixed(0)
                    : (couponApplied.value || 0)}
                </span>
              </div>
            )}
          </div>
          
          <div className="order-total">
            <span>Total</span>
            <span className="cart-total">Rs {calculateFinalTotal()}</span>
          </div>
        </div>
        
        <div className="cart-actions">
          <button 
            className="checkout-btn" 
            onClick={() => setShowModal(true)}
          >
            ✅ Proceed to Checkout
          </button>
          <button 
            className="save-later-btn"
            onClick={saveForLater}
          >
            💾 Save Cart
          </button>
          <button 
            className="clear-btn" 
            onClick={clearCart}
          >
            🧹 Clear Cart
          </button>
        </div>
        
       
      </div>

      {/* Checkout Modal */}
      {showModal && (
        <div className="checkout-modal-overlay" onClick={() => setShowModal(false)}>
          <div className="checkout-modal" onClick={(e) => e.stopPropagation()}>
            <h3>💖 Complete Your Order</h3>
            
            <div className="order-summary">
              <h4>Order Details</h4>
              <div className="order-items">
                {cartItems.map(item => {
                  const itemPrice = getItemPrice(item);
                  return (
                    <div key={item.id} className="order-item">
                      <span>{item.name} × {item.quantity}</span>
                      <span>Rs {(item.quantity * itemPrice).toFixed(0)}</span>
                    </div>
                  );
                })}
              </div>
              <div className="order-total">
                <span>Total Amount</span>
                <span className="cart-total">Rs {calculateFinalTotal()}</span>
              </div>
            </div>
            
            <form onSubmit={handleCheckoutSubmit} className="checkout-form">
              <div className="form-row">
                <input
                  type="text"
                  placeholder="Full Name"
                  value={checkoutData.name}
                  onChange={(e) =>
                    setCheckoutData({ ...checkoutData, name: e.target.value })
                  }
                  required
                />
                <input
                  type="email"
                  placeholder="Email Address"
                  value={checkoutData.email}
                  onChange={(e) =>
                    setCheckoutData({ ...checkoutData, email: e.target.value })
                  }
                  required
                />
              </div>
              
              <div className="form-row">
                <input
                  type="tel"
                  placeholder="Phone Number"
                  value={checkoutData.phone}
                  onChange={(e) =>
                    setCheckoutData({ ...checkoutData, phone: e.target.value })
                  }
                  required
                />
                <input
                  type="text"
                  placeholder="City"
                  value={checkoutData.city}
                  onChange={(e) =>
                    setCheckoutData({ ...checkoutData, city: e.target.value })
                  }
                  required
                />
              </div>
              
              <input
                type="text"
                placeholder="Address"
                value={checkoutData.address}
                onChange={(e) =>
                  setCheckoutData({ ...checkoutData, address: e.target.value })
                }
                required
              />
              
              <div className="form-row">
                <input
                  type="text"
                  placeholder="ZIP Code"
                  value={checkoutData.zipCode}
                  onChange={(e) =>
                    setCheckoutData({ ...checkoutData, zipCode: e.target.value })
                  }
                  required
                />
                <select className="payment-method" required>
                  <option value="">Select Payment</option>
                  <option value="cod">Cash on Delivery</option>
                  <option value="card">Credit/Debit Card</option>
                  <option value="bank">Bank Transfer</option>
                  <option value="jazzcash">JazzCash</option>
                  <option value="easypaisa">EasyPaisa</option>
                </select>
              </div>
              
              <div className="form-buttons">
                <button type="submit" className="submit-btn">
                  🛍️ Confirm Order
                </button>
                <button
                  type="button"
                  className="cancel-btn"
                  onClick={() => setShowModal(false)}
                >
                  ❌ Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default Cart;